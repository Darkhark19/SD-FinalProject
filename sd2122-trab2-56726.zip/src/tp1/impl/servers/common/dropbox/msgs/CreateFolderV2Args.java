package tp1.impl.servers.common.dropbox.msgs;

public record CreateFolderV2Args(String path, boolean autorename) {

}