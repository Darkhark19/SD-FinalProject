package tp1.impl.servers.common.dropbox.msgs;

public record PathArgs(String path) {
}
