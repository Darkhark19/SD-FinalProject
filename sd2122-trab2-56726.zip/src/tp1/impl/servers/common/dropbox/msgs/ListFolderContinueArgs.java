package tp1.impl.servers.common.dropbox.msgs;

public record ListFolderContinueArgs(String cursor) {
}
